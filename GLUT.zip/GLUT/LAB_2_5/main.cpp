#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#define DATA_SIZE 1000
int main()
{
    char data[DATA_SIZE];
    FILE *fp;
    int vowel=0,consonant=0;
    char ch;
    char message[200];
    fp = fopen("input1.txt", "w");
    printf("Enter contents to store in file : \n");
    fgets(data, DATA_SIZE, stdin);
    fputs(data, fp);
    fclose(fp);
    fp=fopen("input1.txt","r");
    if(fp==NULL)
    {
        printf("Source can't be opened");
        exit(-1);
    }
    while(!feof(fp))
    {
        fgets(message, 200, fp);
    }
    printf("\n\n");

    fseek(fp, 0, SEEK_SET);

    while(ch!=EOF)
    {
        ch=fgetc(fp);
        if((ch=='+')||(ch=='-')||(ch=='*')||(ch=='/')||(ch=='%')||(ch=='=')||(ch=='<') ||(ch=='>'))
        {
            vowel++;
            printf("(%c) Operators ", ch);
        }
        else
        {
            printf("");
        }
    }
    fclose(fp);
    return 0;
}
