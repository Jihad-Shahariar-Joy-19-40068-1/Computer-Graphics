#include <iostream>
using namespace std;
int main(){
string line;
int i,flag=0,flag2=1;
string keyword[32]={"auto","double","int","struct","break","else","long",
"switch","case","enum","register","typedef","char","extern","return","union",
"const","float","short","unsigned","continue","for","signed","void",
"default","goto","sizeof","voltile","do","if","static","while"};

//take identifier from user
cout<<"Enter an identifier: ";
cin>>line;

//check line[0] is between A and Z, or line[0] is between a and Z
//or line[0] is _
if((line[0]>='A'&& line[0]<='Z') || (line[0]>='a'&& line[0]<='z') || (line[0]=='_')) {
for(i=1;i<line.length();i++) {
//check line[i] is between 0 and 9, or line[i] is _
//or line[i] is between A and Z, or line[i] is between a and Z
if((line[i]>='0' && line[i]<='9') || (line[i]=='_') || (line[i]>='A' && line[i]<='Z')|| (line[i]>='a' && line[i]<='z') )
{ //set flag to 1
flag=1;
}
else
{ //set flag to 0
flag=0;
}
}
}
else
{ //else set flag to 0
flag=0;
}
for(i=0;i<32;i++)
{ //check identifier is not equal to keyword[i]
if(line==keyword[i])
{ //set flag2 to 0
flag2=0;
break;
}
else
{ //set flag2 to 1
flag2=1;
}
}
//if flag is 1 and flag2 is 1
if(flag==1 && flag2==1)
{ //print Valid identifier
cout<<"Valid identifier";
}
else
{ //else print Not valid identifier
cout<<"Not a valid identifier";
}
return 0;
}
