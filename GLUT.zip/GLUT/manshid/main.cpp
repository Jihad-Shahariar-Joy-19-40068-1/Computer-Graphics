#include <windows.h>
#include <GL/glut.h>


void display() {
glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
glClear(GL_COLOR_BUFFER_BIT);

glBegin(GL_LINES);

glColor3f(0.0f, 1.0f, 0.2f);
//Line-1
glVertex2f(0.0f,0.0f);
glVertex2f(0.8f,0.0f);
glVertex2f(0.8f,0.0f);
glVertex2f(0.8f,0.3f);

glVertex2f(0.8f,0.3f);
glVertex2f(0.0f,0.3f);
glVertex2f(0.0f,0.3f);
glVertex2f(0.0f,0.0f);

glEnd();

 glFlush(); // Render now
}


int main(int argc, char** argv) {
glutInit(&argc, argv);
glutCreateWindow("OpenGL Setup Test");
glutInitWindowSize(1366, 768); // Set the window's initial width & height
glutDisplayFunc(display);
glutMainLoop(); // Enter the event-processing loop
return 0;
}
