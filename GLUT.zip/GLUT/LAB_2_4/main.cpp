// CPP program to find type of input character
#include <iostream>
using namespace std;

int main()
{
	char input;
	cout<<"Enter for checking: ";
	cin>>input;
	if (input >= 48 && input <= 57)
		cout << "numeric constant ";
	else
		cout << "not numeric";
	return 0;
}
