#include <iostream>

using namespace std;

int main()

{

string line;

int flag=0,i;

//take Line from user cout<<"Enter comment:

cin>>line;

//check if Line[0] is /

if(line[0] == '/')

{ //check if Line[1] is /

if(line[1] == '/')

{ //print it is comment

cout<<"It is a comment"

}

//check Line[1] is else if(line[1] == '*')

for(i=2;i<line.length(); i++)

{

//check line[i] is and Line[i+1] is /

if(line[i]==�** && line[i+1] == '/')

{

//set flag to 1

flag=1;

break;

}

}
//if flag is 1 then print it is comment

if(flag==1)

{

cout<<"It is a comment";

}

else

{ //else print it is not a comment cout<<"It is not a comment"

}

}

else

{ //else print it is not a comment cout<<"It is not a comment";

}

return 0;
