#include <GL/glut.h>  // GLUT, include glu.h and gl.h



/* Handler for window-repaint event. Call back when the window first appears and

whenever the window needs to be re-painted. */

void display() {

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque

    glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)

    glLineWidth(.5);

    // Draw a Red 1x1 Square centered at origin

    glBegin(GL_QUADS);              // 1

    glColor3f(0.0f, 1.0f, 1.0f); // Red



    glVertex2f(0.0f, 0.0f);    // x, y

    glVertex2f(0.02f, 0.0f);    // x, y

    glVertex2f(0.02f, 0.4f);    // x, y

    glVertex2f(0.0f, 0.4f);    // x, y





    glBegin(GL_QUADS);              // 2

    glColor3f(0.0f, 0.0f, 1.0f); // Red



    glVertex2f(0.0f, 0.0f);    // x, y

    glVertex2f(0.13f, 0.0f);    // x, y

    glVertex2f(0.13f, 0.04f);    // x, y

    glVertex2f(0.0f, 0.04f);    // x, y



    glBegin(GL_QUADS);              // 3

    glColor3f(0.0f, 0.0f, 1.0f); // Red



    glVertex2f(0.0f, 0.31f);    // x, y

    glVertex2f(0.17f, 0.31f);    // x, y







    glVertex2f(0.17f, 0.4f);    // x, y

    glVertex2f(0.0f, 0.4f);    // x, y







    glEnd();







    glBegin(GL_QUADS);              // 4

    glColor3f(0.0f, 0.0f, 1.0f); // Red







    glVertex2f(0.13f, 0.0f);    // x, y    1

    glVertex2f(0.17f, 0.0f);    // x, y    2







    glVertex2f(0.17f, 0.38f);    // x, y   3

    glVertex2f(0.13f, 0.38f);    // x, y   4







    glEnd();













    glBegin(GL_QUADS);              // 5

    glColor3f(0.0f, 0.0f, 1.0f); // Red







    glVertex2f(0.13f, -0.12f);    // x, y    1

    glVertex2f(0.17f, -0.12f);    // x, y    2







    glVertex2f(0.17f, 0.38f);    // x, y   3

    glVertex2f(0.13f, 0.0f);    // x, y   4







    glEnd();







    glBegin(GL_QUADS);              // 6

    glColor3f(0.0f, 0.0f, 1.0f); // Red







    glVertex2f(0.0f, -0.12f);    // x, y    1

    glVertex2f(0.02f, -0.12f);    // x, y    2



    glVertex2f(0.02f, 0.0f);    // x, y   3

    glVertex2f(0.0f, 0.0f);    // x, y   4



    glEnd();



    glBegin(GL_QUADS);              // 7

    glColor3f(0.0f, 0.0f, 1.0f); // Red



    glVertex2f(0.25f, -0.12f);    // x, y    1

    glVertex2f(0.30f, -0.12f);    // x, y    2



    glVertex2f(0.30f, 0.4f);    // x, y   3

    glVertex2f(0.25f, 0.4f);    // x, y   4





    glEnd();







     glBegin(GL_QUADS);              // 8

    glColor3f(0.0f, 0.0f, 1.0f); // Red







    glVertex2f(0.4f, -0.12f);    // x, y    1

    glVertex2f(0.45f, -0.12f);    // x, y    2







    glVertex2f(0.45f, 0.4f);    // x, y   3

    glVertex2f(0.4f, 0.4f);    // x, y   4







    glEnd();







    glBegin(GL_QUADS);              // 9

    glColor3f(0.0f, 0.0f, 1.0f); // Red







    glVertex2f(0.45f, -0.12f);    // x, y    1

    glVertex2f(0.56f, -0.12f);    // x, y    2







    glVertex2f(0.56f, 0.005f);    // x, y   3

    glVertex2f(0.45f, 0.005f);    // x, y   4







    glEnd();







    glBegin(GL_QUADS);              // 10

    glColor3f(0.0f, 0.0f, 1.0f); // Red







    glVertex2f(0.56f, -0.12f);    // x, y    1

    glVertex2f(0.61f, -0.12f);    // x, y    2







    glVertex2f(0.61f, 0.4f);    // x, y   3

    glVertex2f(0.56f, 0.4f);    // x, y   4







    glEnd();



    glFlush();  // Render now



}



/* Main function: GLUT runs as a console application starting at main()  */

int main(int argc, char** argv) {

    glutInit(&argc, argv);                 // Initialize GLUT

    glutCreateWindow("AIUB TEXT"); // Create a window with the given title

    glutInitWindowSize(320, 320);   // Set the window's initial width & height

    glutDisplayFunc(display); // Register display callback handler for window re-paint

    glutMainLoop();           // Enter the event-processing loop

    return 0;

}
