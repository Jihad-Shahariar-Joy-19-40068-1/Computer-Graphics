#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <sstream>
#define MAX 5
#define max() {}
using namespace std;
int main()
{
    ifstream input("file.txt");
    string line;
    while (getline(input, line, ' '))
    {
        cout << line<<';'<<endl;
    }
    return 0;
}
