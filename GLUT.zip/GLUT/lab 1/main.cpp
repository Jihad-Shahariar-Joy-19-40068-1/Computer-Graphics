#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include <windows.h>

void initGL() {
	// Set "clearing" or background color
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Black and opaque
}


void display() {
    glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)

    glScalef(.77,.66,1);
    glTranslatef(.9,.9,0);

    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.1,.15,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.55,0);
        glVertex3f(.2,.55,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.1,.15,0);
    glEnd();
    glFlush();  // Render now

}

int main(int argc, char** argv) {
  glutInit(&argc, argv);            // Initialize GLUT
  glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
  glutInitWindowSize(320, 320);   // Set the window's initial width & height
  glutDisplayFunc(display); // Register display callback handler for window re-paint
  glutMainLoop();           // Enter the event-processing loop
  return 0;
}
