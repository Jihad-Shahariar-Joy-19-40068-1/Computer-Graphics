#include<iostream>
#include<stdio.h>
#include<string>
#include<fstream>
#include <bits/stdc++.h>

using namespace std;

int main ()
{
    int Size,Sum=0;
    cout<<"Enter Array Size : ";
    cin>>Size;
    int Arr[Size];
    cout<<"enter values for summation : "<<endl;
    for(int i=0; i<Size; i++)
    {
        cin>>Arr[i];
    }
    int Max = Arr[0];
    for(int i = 1; i<Size; i++)
    {
        if(Max<Arr[i])
         Max = Arr[i];
    }
    cout<<"Maximum Value = "<<Max<<endl;

    int Min = Arr[0];
    for(int i = 1; i<Size; i++)
    {
        if(Min>Arr[i])
         Min = Arr[i];
    }
    cout<<"Minimum Value = "<<Min<<endl;
}
