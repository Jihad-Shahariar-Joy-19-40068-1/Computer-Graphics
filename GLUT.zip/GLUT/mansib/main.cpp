#include <windows.h> // for MS Windows
#include <GL/glut.h> // GLUT, include glu.h and gl.h
#include <math.h>

void display() {
glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
glClear(GL_COLOR_BUFFER_BIT);

//road
glColor3ub(150,150,150);
glBegin(GL_QUADS);
glVertex2i(0,0);
glVertex2i(2000,0);
glVertex2i(2000,350);
glVertex2i(0,350);

//walking space
glColor3ub(100,50,50);
glBegin(GL_QUADS);
glVertex2i(0,350);
glVertex2i(2000,350);
glVertex2i(2000,480);
glVertex2i(0,480);

//grass

glColor3ub(0,150,350);
glBegin(GL_QUADS);
glVertex2i(0,480);
glVertex2i(2000,480);
glVertex2i(2000,650);
glVertex2i(0,650);

//sky
glColor3ub(0,150,250);
glBegin(GL_QUADS);
glVertex2i(0,650);
glVertex2i(2000,650);
glVertex2i(2000,1000);
glVertex2i(0,1000);

//lamp post
glColor3ub(150,100,0);
glBegin(GL_QUADS);
glVertex2i(350,350);
glVertex2i(385,350);
glVertex2i(385,700);
glVertex2i(350,700);

glColor3ub(150,100,0);
glBegin(GL_QUADS);
glVertex2i(385,680);
glVertex2i(435,680);
glVertex2i(435,700);
glVertex2i(385,700);

glColor3ub(233,255,0);
glBegin(GL_QUADS);
glVertex2i(415,685);
glVertex2i(460,685);
glVertex2i(460,695);
glVertex2i(415,695);

void car(){
}

int isbaby=0;
int shipx=0;

 if(isbaby==8)
    {

        shipx=shipx-1;
        if(shipx<-25)
            shipx=20;

    }
glPushMatrix();
glTranslated(0+shipx,0.8,0);
glScaled(0.5,0.2,0);
glColor3ub(0,55,100);
glBegin(GL_POLYGON);
glVertex2i(450,100);
glVertex2i(800,100);
glVertex2i(800,185);
glVertex2i(450,185);

//car hood
glBegin(GL_POLYGON);
glColor3ub(0,100,150);
glVertex2i(550,185);
glVertex2i(750,185);
glVertex2i(700,250);
glVertex2i(600,250);
glVertex2i(0,0);
glVertex2i(0,0);

glEnd();

//wheel
glLineWidth(8.5);

glBegin(GL_POLYGON);

for(int i=0;i<500;i++)

{

glColor3ub(50,50, 50);

float pi=3.1416;

float A=(i*2*pi)/500;

float r=35;

float x = r * cos(A);

float y = r * sin(A);

glVertex2f(730+x,100+y);

}

glEnd();

//2nd back tire
glLineWidth(8.5);

glBegin(GL_POLYGON);

for(int i=0;i<500;i++)

{

glColor3ub(50, 50, 50);

float pi=3.1416;

float A=(i*2*pi)/500;

float r=35;

float x = r * cos(A);

float y = r * sin(A);

glVertex2f(530+x,100+y);

}

glEnd();

glFlush(); // Render now
glPopMatrix();
}

/*Main function: GLUT runs as a console application starting at main() */
int main(int argc, char** argv) {
glutInit(&argc, argv); // Initialize GLUT
glutCreateWindow("Scenario");
gluOrtho2D(0.0,1500,0.0,900); // Create a window with the given title
glutInitWindowSize(1024, 720);// Set the window's initial width & height
glutDisplayFunc(display);// Register display callback handler for window re-paint
glutMainLoop(); // Enter the event-processing loop
return 0;
}
