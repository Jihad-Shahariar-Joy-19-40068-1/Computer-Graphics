#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include <stdio.h>
#include <string.h>

using namespace std;
int firstCheck(char check[])
{
    int str_length = strlen(check);
    if(str_length==0)
    {
        return 1;
    }

    if(check[0] != 'a')
    {
        return 2;
    }
    if(check[1] != 'b')
    {
        return 2;
    }

    for(int i=2; i<str_length ; i++)
    {
        if(check[i] != 'c')
    {
        return 2;
    }

    }
    return 1;
}

int secondCheck(char check[])
{
    int str_length = strlen(check);
    if(check[0] != 'a')
    {
        return 2;
    }
    if(check[1] != 'b')
    {
        return 2;
    }

    for(int i=2; i<str_length ; i++)
    {
        if(check[i] != 'c')
    {
        return 2;
    }

    }
    return 1;
}

int thirdCheck(char check[])
{
    int str_length = strlen(check);
    for(int i=0; i<str_length ; i++)
    {
        if(check[i] >= 'a' && check[i] <= 'z')
    {
        return 1;
    }
    return 2;

}
}
int fourthCheck(char check[])
{
    int str_length = strlen(check);

        if(check[0] == 'a' || check[0] == 'b' || check[0] == 'c')
    {
        return 1;
    }
    return 2;

}


int main() {
    char a[100];
    int sw;
    cout << "Choose an reg expression number: \n abc* -->1 \n abc+ -->2 \n [a-z] -->3 \n [a,b,c] -->4 \n ";
    cin >> sw;
    cout << "Enter a string for your expression: ";
    gets(a);


    switch (sw) {
        case '1':
            int r1=firstCheck(a);
            if(r1==1){cout << "pattern Matched";}
            else{cout << "Not Matched";}

            break;
        case '2':
            int r2=secondCheck(a);
            if(r2==1){cout << "pattern Matched";}
            else{cout << "Not Matched";}
            break;
        case '3':
            int r3 =thirdCheck(a);
            if(r3==1){cout << "pattern Matched";}
            else{cout << "Not Matched";}
            break;
        case '4':
            int r4=fourthCheck(a);
            if(r4==1){cout << "pattern Matched";}
            else{cout << "Not Matched";}
            break;
        default:
            cout << "incorrect value.";
            break;
    }

    return 0;
}
