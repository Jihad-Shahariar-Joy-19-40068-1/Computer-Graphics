#include <bits/stdc++.h>
using namespace std;
bool isValid(string str)
{
	int k = 0;
	string operands[5] = "";
	char operators[4];
	long ans = 0, ans1 = 0, ans2 = 0;
	for (int i = 0; i < str.length(); i++) {
		if (str[i] != '+' && str[i] != '=' && str[i] != '-')
			operands[k] += str[i];
		else {
			operators[k] = str[i];
			if (k == 1) {
				if (operators[k - 1] == '+')
					ans += stol(operands[k - 1]) + stol(operands[k]);

				if (operators[k - 1] == '-')
					ans += stol(operands[k - 1]) - stol(operands[k]);
			}

		}
	}
	if (ans2 == stol(operands[4]))
		return true;
	else
		return false;
}
int main()
{
    cout<<"Enter value : ";
	string str;
	cin>>str;
	if (isValid(str))
		cout << "Valid";
	else
		cout << "Invalid";

	return 0;
}
