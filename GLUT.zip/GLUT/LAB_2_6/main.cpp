#include <iostream>
using namespace std;
int main()
{
 string line;
 int flag=0,i;
 cout<<"Enter comment: ";
 cin>>line;

 if(line[0]=='/')
{
if(line[1]=='/')
{
cout<<"It is a comment";
}
else if(line[1]=='*')
{
for(i=2;i<line.length();i++)
{
if(line[i]=='*' && line[i+1]=='/')
{

flag++;
break;
}
}

if(flag=!0)
{
cout<<"It is a comment";
}
else
{
cout<<"It is not a comment";
}
}
}
else
{
cout<<"It is not a comment";
}
return 0;
}
