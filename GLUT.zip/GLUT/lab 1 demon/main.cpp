#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>
#include <iostream>
# define PI           3.14159265358979323846
/* Handler for window-repaint event. Call back when the window first appears and
whenever the window needs to be re-painted. */
using namespace std;

GLfloat x;
GLfloat y;

void display() {
    glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)

    glScalef(1.4,1.4,1.4);
    glTranslatef(0.0,-0.2,0);

    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.1,.15,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.55,0);
        glVertex3f(.2,.55,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.1,.15,0);
    glEnd();
    glLoadIdentity();

    glScalef(.5,.5,1);
    glTranslatef(1.5,1.2,0);

    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.1,.15,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.55,0);
        glVertex3f(.2,.55,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.1,.15,0);
    glEnd();
    glLoadIdentity();


    glScalef(.5,.5,1);
    glTranslatef(-1.5,1.2,0);

    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.1,.15,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.55,0);
        glVertex3f(.2,.55,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.1,.15,0);
    glEnd();
    glLoadIdentity();


    glScalef(.5,.5,1);
    glTranslatef(-1.5,-1.2,0);

    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.1,.15,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.55,0);
        glVertex3f(.2,.55,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.1,.15,0);
    glEnd();
    glLoadIdentity();


    glScalef(.5,.5,1);
    glTranslatef(1.5,-1.2,0);

    glBegin(GL_LINE_LOOP);
        glVertex3f(0,0,0);
        glVertex3f(-.1,.15,0);
        glVertex3f(-.16,.15,0);
        glVertex3f(-.19,.25,0);
        glVertex3f(-.1,.25,0);
        glVertex3f(-.17,.35,0);
        glVertex3f(-.24,.37,0);
        glVertex3f(-.27,.45,0);
        glVertex3f(-.12,.45,0);
        glVertex3f(-.2,.55,0);
        glVertex3f(.2,.55,0);
        glVertex3f(.12,.45,0);
        glVertex3f(.27,.45,0);
        glVertex3f(.24,.37,0);
        glVertex3f(.17,.37,0);
        glVertex3f(.1,.25,0);
        glVertex3f(.19,.25,0);
        glVertex3f(.16,.15,0);
        glVertex3f(.1,.15,0);
    glEnd();
    glLoadIdentity();



    glFlush();  // Render now
}


int main(int argc, char** argv) {
  glutInit(&argc, argv);            // Initialize GLUT


  glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
  glutInitWindowSize(320, 320);   // Set the window's initial width & height
  glutDisplayFunc(display); // Register display callback handler for window re-paint
  glutMainLoop();           // Enter the event-processing loop
  return 0;
}
