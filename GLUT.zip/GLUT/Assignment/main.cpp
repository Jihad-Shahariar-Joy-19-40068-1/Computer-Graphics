#include<windows.h>
#include<GL/glut.h>
#include<math.h>
# define PI           3.14159265358979323846


void display(){

glClearColor(0.0f,1.0f,0.0f,0.0f);
 glClear(GL_COLOR_BUFFER_BIT);

 glBegin(GL_QUADS);

	glColor3f(0.81,0.88,0.88);
	glVertex2f(0.55,0.0);
	glVertex2f(0.55,0.175);
	glVertex2f(0.25,0.175);
	glVertex2f(0.25,0.0);
	glEnd();

 int i;

	GLfloat x=.4f; GLfloat y=.4f; GLfloat radius =.3f;
	int triangleAmount = 40;
	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
		            x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();
	//door############
    glBegin(GL_QUADS);

	glColor3f(0.5,0.7,1.0);
	glVertex2f(0.45,0.0);
	glVertex2f(0.45,0.1);
	glVertex2f(0.35,0.1);
	glVertex2f(0.35,0.0);
	glEnd();
    //DOORLINE#####
	 glBegin(GL_LINES);

	glColor3f(0.0,0.0,0.0);
	glVertex2f(0.4,0.0);
	glVertex2f(0.4,0.1);

	glEnd();
	//CENTERGLASS#############

     glLineWidth(10);

	 glBegin(GL_LINES);


	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.35,0.4);
	glVertex2f(0.45,0.4);

	glEnd();
	glLineWidth(10);

   glBegin(GL_LINES);

	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.6,0.405);
	glVertex2f(0.45,0.4);

	glEnd();

	glLineWidth(10);

	 glBegin(GL_LINES);
	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.6,0.405);
	glVertex2f(0.7,0.41);

	glEnd();

	glLineWidth(10);

   glBegin(GL_LINES);

	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.2,0.405);
	glVertex2f(0.35,0.4);

	glEnd();

	glLineWidth(10);

	 glBegin(GL_LINES);
	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.2,0.405);
	glVertex2f(0.1,0.41);

	glEnd();

	//UPPER GLASS############
	glLineWidth(10);

	 glBegin(GL_LINES);


	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.35,0.55);
	glVertex2f(0.45,0.55);

	glEnd();

	glLineWidth(10);

   glBegin(GL_LINES);

	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.6,0.555);
	glVertex2f(0.45,0.55);

	glEnd();

	glLineWidth(10);

	 glBegin(GL_LINES);
	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.6,0.555);
	glVertex2f(0.65,0.56);

	glEnd();

	glLineWidth(10);

   glBegin(GL_LINES);

	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.2,0.555);
	glVertex2f(0.35,0.55);

	glEnd();

	glLineWidth(10);

	 glBegin(GL_LINES);
	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.2,0.555);
	glVertex2f(0.15,0.56);

	glEnd();

	//lower GLass#############
	glLineWidth(10);

	 glBegin(GL_LINES);


	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.35,0.25);
	glVertex2f(0.45,0.25);

	glEnd();

	glLineWidth(10);

   glBegin(GL_LINES);

	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.6,0.255);
	glVertex2f(0.45,0.25);

	glEnd();

	glLineWidth(10);

	 glBegin(GL_LINES);
	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.6,0.255);
	glVertex2f(0.65,0.26);

	glEnd();

	glLineWidth(10);

   glBegin(GL_LINES);

	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.2,0.255);
	glVertex2f(0.35,0.25);

	glEnd();

	glLineWidth(10);

	 glBegin(GL_LINES);
	glColor3f(0.0,0.0,1.0);
	glVertex2f(0.2,0.255);
	glVertex2f(0.15,0.26);

	glEnd();



 glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutCreateWindow("AIUB c Building");
	glutInitWindowSize(320, 320);
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
